package com.example.lexiBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LexiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
